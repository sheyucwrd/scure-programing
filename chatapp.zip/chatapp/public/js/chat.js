// If you have any questions about this project, please feel free to ask us!
// -a1906010@adelaide.edu.au (Sheyu)
// -a1878433@adelaide.edu.au (Hanny)
// -a1867556@adelaide.edu.au (Eric)
// -a1837777@adelaide.edu.au (Zane)

// establish a real-time connection io() api is responsible for establishing the connection socket is responsible for completing real-time communication
const socket = io()

// Template chat window
const messageTemplate = document.querySelector('#message-template').innerHTML
const locationMessageTemplate = document.querySelector('#message-location').innerHTML
const sideBarTemplate = document.querySelector('#sidebar-template').innerHTML
const sidebarRoom = document.querySelector('#sidebar-room').innerHTML

const sidebarSelect = document.querySelector('#sidebar-select')?document.querySelector('#sidebar-select').innerHTML:''
const fileUploadTemplate = document.querySelector('#file-upload').innerHTML
const key=''
// Creating a Variable Oriented Message Insertion Location
const $messages = document.querySelector('#messages')
const $sendLocationButton = document.querySelector('#send-location')

const { username, room } = Qs.parse(location.search, { ignoreQueryPrefix: true })

// Automatic exit heartbeat detection mechanism to periodically check whether users are active or not
const heartbeatInterval = 10 * 60 * 1000; 

function sendHeartbeat() {
    console.log("data")
    fetch('/heartbeat', {
        method: 'POST',
        credentials: 'include' 
    })
    .then(response => {
        if (response.status === 401) {
            logOut()
        }
    })
    .catch(error => {
        console.error('Error sending heartbeat:', error);
    });
}
function logOut() {
    window.location.href = '/index.html';
}
let timeId= null
function restarttime(){
    timeId=setInterval(sendHeartbeat, heartbeatInterval);
}
restarttime()
document.addEventListener('mousemove', () => {
   
    clearInterval(timeId); // 清除定时器
    restarttime()//重启定时器
});

socket.on('userConnect', (message) => {
    console.log(username,message.username)
    const html = Mustache.render(messageTemplate, {
        username: message.username,
        loginUsername: username === message.username ? 'right' : '',
        text: message.text,
        createdAt: moment(message.createdAt).format('hh:mm A')
    });
    $messages.insertAdjacentHTML('beforeend', html);
});

socket.on('sendMessage', (message) => {
    const decryptor = new JSEncrypt();
    if(message.recipient==='all'){
        decryptor.setPrivateKey(message.private_key);
    }else if(username ===message.recipient ||username ===message.username){//判断是否是目标用户||判断是否是自己
        decryptor.setPrivateKey(message.private_key);
    }
    
    const decryptedAESKeyHex = decryptor.decrypt(message.aesKey);
    if (!decryptedAESKeyHex) {
        console.error('Failed to decrypt AES key');
        return;
    }
    const aesKey = CryptoJS.enc.Hex.parse(decryptedAESKeyHex);
    const decryptedMessage = CryptoJS.AES.decrypt(message.text, aesKey, { iv: message.iv }).toString(CryptoJS.enc.Utf8);

    const html = Mustache.render(messageTemplate, {
        username: message.username,
        text: decryptedMessage,
        loginUsername: username === message.username ? 'right' : '',
        createdAt: moment(message.createdAt).format('hh:mm A')
    });

    $messages.insertAdjacentHTML('beforeend', html);
    document.querySelector(".textarea").value=''
});

socket.on('adminConnect', (message) => {
    const html = Mustache.render(messageTemplate, {
        username: message.username,
        room: message.room,
        text: message.text,
        createdAt: moment(message.createdAt).format('hh:mm A')
    });
    $messages.insertAdjacentHTML('beforeend', html);
});
//解密
socket.on('fileReceived', (file) => {
    const blob = new Blob([new Uint8Array(file.fileData)], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);

    const html = Mustache.render(fileUploadTemplate, {
        username: file.username,
        fileurl: url,
        fileName: file.fileName,
        createdAt: moment(file.createdAt).format('hh:mm A')
    });
    if(file.recipient==='all'){
        $messages.insertAdjacentHTML('beforeend', html);
    }else if(username ===file.recipient ||username ===file.username){//判断是否是目标用户||判断是否是自己
        $messages.insertAdjacentHTML('beforeend', html);
    }
  
});

socket.on('adminFileReceived', (file) => {
    const blob = new Blob([new Uint8Array(file.fileData)], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);

    const html = Mustache.render(fileUploadTemplate, {
        username: file.username,
        room: file.room,
        fileurl: url,
        fileName: file.fileName,
        createdAt: moment(file.createdAt).format('hh:mm A')
    });
    $messages.insertAdjacentHTML('beforeend', html);
});

socket.on('userLocation', (location) => {
    console.log(location)
    const html = Mustache.render(locationMessageTemplate, {
        username: location.username,
        url: location.url,
        createdAt: moment(location.createdAt).format('hh:mm A')
    });
    $messages.insertAdjacentHTML('beforeend', html);
});

socket.on('roomData', ({ room, users,offUsers }) => {

   let selectUser=[]
    selectUser=users.filter(item=>{
        return item.username!==username
    })
   users = users.map(item=>{
        return {
            ...item,
            className:item.username==username?'liSelect':''
        }
    })
    
    const html = Mustache.render(sideBarTemplate, { room, users ,offUsers});
    const html1 = Mustache.render(sidebarSelect, { room,selectUser  });
    const html2 = Mustache.render(sidebarRoom, { room  });
    // const html3 = Mustache.render(sideBarTemplate, { room, offUsers });
    document.querySelector('#sidebar').innerHTML = html;
    document.querySelector('.room').innerHTML = html2;
    if(document.querySelector('.select')){
        document.querySelector('.select').innerHTML = html1;
    }
   
});

socket.on('keyTransfer', (key) => {
    sessionStorage.setItem(`public_key_${key.username}`, key.publicKey);
    sessionStorage.setItem(`private_key_${key.username}`, key.privateKey);
});

document.querySelector('#message-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const message = e.target.elements.message.value;
    let recipient=''
    if(document.querySelector('.select')){
        recipient=document.querySelector("#select").value
    }
    
    const aesKey = CryptoJS.lib.WordArray.random(32);
    const iv = CryptoJS.lib.WordArray.random(16);

    const public_key = sessionStorage.getItem(`public_key_${username}`);
    const private_key = sessionStorage.getItem(`private_key_${username}`);
    const encryptor = new JSEncrypt();
    encryptor.setPublicKey(public_key);

    const encryptedAESKey = encryptor.encrypt(CryptoJS.enc.Hex.stringify(aesKey));
    const encryptedMessage = encryptAES(message);

    socket.emit('sendMessage', { encryptedMessage, encryptedAESKey, iv, private_key,recipient}, (error) => {
        if (error) {
            return console.log(error);
        }
        console.log('Message Delivered!');
    });

    function encryptAES(message) {
        const encrypted = CryptoJS.AES.encrypt(message, aesKey, { iv: iv });
        return encrypted.toString();
    }
});

document.querySelector('#send-location').addEventListener('click', (e) => {
    if (!navigator.geolocation) {
        return alert("Geolocation is not supported!");
    }

    navigator.geolocation.getCurrentPosition((position) => {
        socket.emit('sendLocation', position, (error) => {
            if (error) {
                return console.log(error);
            }
            console.log('Location Shared!');
        });
    });
});

document.querySelector('#file-transfer').addEventListener('click', () => {
    document.querySelector('#file-input').click();
});

document.querySelector('#file-input').addEventListener('change', (event) => {
    const file = event.target.files[0];
    if (!file) return;
    let recipient=''
    if(document.querySelector('.select')){
        recipient=document.querySelector("#select").value
    }
    const reader = new FileReader();
    reader.onload = function (e) {
        const buffer = e.target.result;
        socket.emit('fileUpload', {
            fileName: file.name,
            fileData: buffer,
            recipient,
        });
    };
    reader.readAsArrayBuffer(file);
});

const autoScroll = () => {
    // New message element
    const $newMessage = $messages.lastElementChild;

    // Height of the new message
    const newMessageStyles = getComputedStyle($newMessage);
    const newMessageMargin = parseInt(newMessageStyles.marginBottom);
    const newMessageHeight = $newMessage.offsetHeight + newMessageMargin;

    // Visible height
    const visibleHeight = $messages.offsetHeight;

    // Height of messages container
    const containerHeight = $messages.scrollHeight;

    // How far have I scrolled?
    const scrollOffset = $messages.scrollTop + visibleHeight;

    if (containerHeight - newMessageHeight <= scrollOffset) {
        $messages.scrollTop = $messages.scrollHeight;
    }
};

socket.emit('join', { username, room }, (error) => {
    if (error) {
        alert(error);
        location.href = '/';
    }
});
