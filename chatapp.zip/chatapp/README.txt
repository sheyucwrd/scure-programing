# Real-time Chat Application with Heartbeat Mechanism

## Overview

This project is a real-time chat application that incorporates a heartbeat mechanism to monitor user activity. It is developed using **Node.js**, **Express**, and **Socket.io** on the server-side, with **Mustache.js**, **CryptoJS**, **Qs.js**, and **moment.js** on the client-side. The application supports real-time communication, file sharing, geolocation sharing, and administrative functionalities.

See [HERE](https://github.com/xvk-64/2024-secure-programming-protocol) for the project specification.

## Project Structure

- **index.js**: The main server file. It initializes the Express server, manages WebSocket connections, and implements the heartbeat mechanism.
- **messages.js**: Contains helper functions to generate messages, manage file transfers, and perform encryption key exchanges.
- **users.js**: Handles user management within chat rooms, including user joining, leaving, and listing functions.
- **chat.html**: The primary user interface for the chat application.
- **admin.html**: A dedicated interface for administrators, providing additional control and information.
- **heartbeat.js**: Implements the heartbeat mechanism on the client side to check user activity.

## How to Install and Run the Code

1. **Install Dependencies**:
   Make sure **Node.js** is installed. In the project root directory, run the following command to install the required packages:

   ```bash
   npm install
   npm install socket.io crypto express-session
   ```

2. **Start the Server**:
   Once the dependencies are installed, start the server using the following command:

   ```bash
   node index.js
   ```

   The server will run on port 3000 by default. Open your browser and navigate to `http://localhost:3000` to use the application.

## Usage Example

1. **Joining a Chat Room**:
   Open the `index.html` file in your browser. Enter your username and the room name you wish to join. The system will route you to the appropriate chat room or to the admin page based on your credentials.

2. **Sending Messages**:
   In the chat room, you can send text messages, share your location, or upload files using the available buttons. All chat content is shared within the same room, and content is isolated between different chat rooms. (Note: Messages are encrypted, but due to decryption issues, message-sending functionality is currently limited.)

## Heartbeat Mechanism

The application features a heartbeat mechanism that checks user activity every 10 minutes. If a user becomes inactive or leaves, the system automatically logs them out and redirects them to the login page. This feature is implemented in both `heartbeat.js` and `chat.js`.

## Guidelines for Other Groups

- **Protocol**: The chat application follows a standard WebSocket protocol, but other groups can extend or modify the protocol as needed, such as by adding extra encryption layers or customizing message types.
- **File Structure**: If you plan to extend the application, ensure that new features are modularized. For example, new functionalities should be added as separate modules or functions, similar to `messages.js` and `users.js`.
- **Security**: The current implementation provides basic encryption for messages and files. For handling sensitive data, it is advisable to enhance the encryption methods and verify user session tokens to increase security.



## If you have any questions about this project, please feel free to ask us!
-a1906010@adelaide.edu.au (Yuxuan Xie)
-a1878433@adelaide.edu.au (XiaoHan)
-a1867556@adelaide.edu.au (Yiu Lung Tam)
-a1837777@adelaide.edu.au (Zhenyang Li)