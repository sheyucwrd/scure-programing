// If you have any questions about this project, please feel free to ask us!
// -a1906010@adelaide.edu.au (Yuxuan Xie)
// -a1878433@adelaide.edu.au (XiaoHan)
// -a1867556@adelaide.edu.au (Yiu Lung Tam)
// -a1837777@adelaide.edu.au (Zhenyang Li)
const users =[]
let offlineUsers = users.filter(user => !user.active && user.room === room);

const addUser =({id, username, room}) => {
    username = username.trim().toLowerCase()
    room = room.trim().toLowerCase()

    if(!username || !room) {
        return{
            error: 'Username and room are required!'
        }
    }
    const existingUser = users.find((user) =>{
        return user.room === room && user.username === username
    })

    if (existingUser) {
        return{
            error:'Username is in used!'
        }
    }

    const user ={id, username,room,state:1}
    users.push(user)
    return {user}
}

const getOfflineUsersInRoom = (room) => {
    //根据房间号筛选
  let  outList= offlineUsers.filter((user) => user.room === room)
    //判断离线数组里面的name是否在在线用户数组里面，如果用户在线，着过滤掉离线数组的数组，（比如小皮在线，离线的数组里面存在一个或者多个小皮着清空离线数组的小皮）
    outList= outList.filter(item1 => !users.some(item2 => item1.username === item2.username));
    outList = outList.filter((item, index, self) =>
    index === self.findIndex((t) => t.username === item.username)
);
    return  outList
}

const removeUser = (id) =>{
    const index = users.findIndex((user)=> user.id ===id)
    if(index !==-1){
        const removedUser = users.splice(index, 1)[0];
        offlineUsers.push(removedUser);
        return removedUser; 
    }
}

const getUser = (id) =>{
    return users.find((user) => user.id === id)
}

const getUserInRoom = (roomName) =>{
    roomName = String(roomName).trim().toLowerCase();
    return users.filter((user) => user.room === roomName)
}

module.exports ={
    addUser,
    removeUser,
    getUser,
    getUserInRoom,
    getOfflineUsersInRoom,
}