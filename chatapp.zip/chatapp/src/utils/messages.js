// If you have any questions about this project, please feel free to ask us!
// -a1906010@adelaide.edu.au (Yuxuan Xie)
// -a1878433@adelaide.edu.au (XiaoHan)
// -a1867556@adelaide.edu.au (Yiu Lung Tam)
// -a1837777@adelaide.edu.au (Zhenyang Li)
//Message Generation Functions
const generateInformation = (username,text,aesKey,iv,private_key,recipient) =>{
    return {
        username,
        text,
        aesKey,
        iv,
        private_key,
        recipient,
        createdAt: new Date().getTime()
    }
}
//address generation function
const getLocation = (username,url) =>{
    return {
        username,
        url,
        createdAt: new Date().getTime()
    }
}

const getAdminInformation = (username,room,text) =>{
    return {
        username,
        room,
        text,
        createdAt: new Date().getTime()
    }
}

const getFileInformation = (username,fileData,fileName,recipient) =>{
    return {
        username,
        fileData,
        fileName,
        recipient,
        createdAt: new Date().getTime()
    }
}

const getAdminFile = (username,room,fileData,fileName) =>{
    return {
        username,
        room,
        fileData,
        fileName,
        createdAt: new Date().getTime()
    }
}

const getKeyMessage = (username,publicKey,privateKey) =>{
    return {
        username,
        publicKey,
        privateKey,
        createdAt: new Date().getTime()
    }
}
module.exports = {
    generateInformation,
    getLocation,
    getFileInformation,
    getAdminInformation,
    getAdminFile,
    getKeyMessage,
}