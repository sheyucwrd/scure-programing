// If you have any questions about this project, please feel free to ask us!
// -a1906010@adelaide.edu.au (Yuxuan Xie)
// -a1878433@adelaide.edu.au (XiaoHan)
// -a1867556@adelaide.edu.au (Yiu Lung Tam)
// -a1837777@adelaide.edu.au (Zhenyang Li)

// Import the express module, which is a simplified web framework.
const express = require('express');
const path = require('path');
const http = require('http');
const socketio = require('socket.io');
const crypto = require('crypto');
const session = require('express-session');
const { generateInformation, getLocation, getFileInformation, getAdminInformation, getAdminFile, getKeyMessage } = require('./utils/messages');
const { addUser, removeUser, getUser, getUserInRoom, getOfflineUsersInRoom } = require('./utils/users');

// Instantiate an express object called app app is actually a request handler function that handles HTTP requests.
const app = express();

// Using session middleware
app.use(session({
    secret: 'your-secret-key', // Use a secure key
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false }  // If you are using https, set it to true
}));

// Create an http server via http.createServer The parameter is usually a callback function that will process each time an http request arrives and return a response (aka the app's function)
const server = http.createServer(app);

// Use the socket.io library to create a websocket server and connect it to an existing server for real-time two-way communication.
const io = socketio(server);

// Used to set the port on which the application will run. It serves to ensure that the application can run in different environments
const port = process.env.PORT || 3000;

// Get the path to the current project folder
const publicDirectoryPath = path.join(__dirname, '../public');

// Handling static files All files in the publicDirectoryPath path can be accessed automatically.
app.use(express.static(publicDirectoryPath));

// Heartbeat detection routing to check if users are still active
app.post('/heartbeat', (req, res) => {
    // Assuming you have a session or token to check if a user is logged in or not
    if (req.session && req.session.isLoggedIn) {
        res.sendStatus(200);  // Users are active and continue to stay logged in
    } else {
        res.sendStatus(401);  // User is no longer active or login expired, return 401 Unauthorized
    }
});

let message = 'Welcome';

// Listens for each client WebSocket connection
io.on('connection', (socket) => {
    console.log('New WebSocket Connection!');

    socket.on('join', ({ username, room }, callback) => {
        const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', {
            modulusLength: 2048,
            publicKeyEncoding: { type: 'spki', format: 'pem' },
            privateKeyEncoding: { type: 'pkcs8', format: 'pem' }
        });

        socket.emit('keyTransfer', getKeyMessage(username, publicKey, privateKey));

        const { error, user } = addUser({ id: socket.id, username, room ,state:1});
        if (error) {
            return callback(error);
        }

        if (username === 'admin' && room === 'admin') {
            io.to(socket.id).emit('adminConnect', getAdminInformation('Admin', 'admin room', 'Welcome to Admin page'));
        }

        socket.join(user.room);
        socket.emit('userConnect', generateInformation(getUser(socket.id).username, 'Welcome!', '', ''));
        socket.broadcast.to(user.room).emit('userConnect', generateInformation('Admin', 'A new user has joined', '', ''));

        io.to(user.room).emit('roomData', {
            room: user.room,
            users: getUserInRoom(user.room),
            offUsers:getOfflineUsersInRoom(user.room)
        });

        callback();
    });

    socket.on('sendMessage', ({ encryptedMessage, encryptedAESKey, iv, private_key,recipient }, callback) => {
        const getUserRoom = getUser(socket.id).room;
        io.to(getUserRoom).emit('sendMessage', generateInformation(getUser(socket.id).username, encryptedMessage, encryptedAESKey, iv, private_key,recipient));
        io.to('admin').emit('adminConnect', getAdminInformation(getUser(socket.id).username, getUserRoom, encryptedMessage));
        callback();
    });

    socket.on('fileUpload', ({ fileName, fileData,recipient }, callback) => {
        const getUserRoom = getUser(socket.id).room;
        console.log(`Received file: ${fileName}`);
        io.to(getUserRoom).emit('fileReceived', getFileInformation(getUser(socket.id).username, fileData, fileName,recipient));
        io.to('admin').emit('adminFileReceived', getAdminFile(getUser(socket.id).username, getUserRoom, fileData, fileName));
    });

    socket.on('sendLocation', (position, callback) => {
        const location = "https://www.google.com/maps?q=" + position.coords.longitude + "," + position.coords.latitude;

        if (position) {
            io.emit('userLocation', getLocation(getUser(socket.id).username, location));
            callback();
        } else {
            return callback('Location is invalid');
        }

        callback();
    });

    socket.on('disconnect', () => {
        io.emit('userConnect', generateInformation('A user has left', '', '', ''));
        const user = removeUser(socket.id);
        if (user) {
            io.to(user.room).emit('userConnect', generateInformation('Admin', `${user.username} has left!`, '', ''));
            io.to(user.room).emit('roomData', {
                room: user.room,
                users: getUserInRoom(user.room),
                offUsers:getOfflineUsersInRoom(user.room)
            });
        }
    });
});

// Start the server
server.listen(port, () => {
    console.log(`Server is up on port ${port}!`);
});